/*
 * Licensed to the OpenAirInterface (OAI) Software Alliance under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The OpenAirInterface Software Alliance licenses this file to You under 
 * the Apache License, Version 2.0  (the "License"); you may not use this file
 * except in compliance with the License.  
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *-------------------------------------------------------------------------------
 * For more information about the OpenAirInterface (OAI) Software Alliance:
 *      contact@openairinterface.org
 */


/*! \file s6a_peers.c
   \brief Add a new entity to the list of peers to connect
   \author Sebastien ROUX <sebastien.roux@eurecom.fr>
   \date 2013
   \version 0.1
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <pthread.h>

#include "bstrlib.h"

#include "log.h"
#include "common_types.h"
#include "intertask_interface.h"
#include "common_defs.h"
#include "s6a_defs.h"
#include "s6a_messages.h"
#include "assertions.h"
#include "dynamic_memory_check.h"
#include "mme_config.h"

extern __pid_t g_pid;


void
s6a_peer_connected_cb (
  struct peer_info *info,
  void *arg)
{
  if (info == NULL) {
    OAILOG_ERROR (LOG_S6A, "Failed to connect to HSS entity\n");
  } else {
    MessageDef                             *message_p;

    OAILOG_DEBUG (LOG_S6A, "Peer %*s is now connected...\n", (int)info->pi_diamidlen, info->pi_diamid);
    /*
     * Inform S1AP that connection to HSS is established
     */
    message_p = itti_alloc_new_message (TASK_S6A, ACTIVATE_MESSAGE);
    itti_send_msg_to_task (TASK_S1AP, INSTANCE_DEFAULT, message_p);
  }

  /*
   * For test
   */
#if 0
  s6a_auth_info_req_t                     s6a_air;

  memset (&s6a_air, 0, sizeof (s6a_auth_info_req_t));
  sprintf (s6a_air.imsi, "%14llu", 20834123456789ULL);
  s6a_air.nb_of_vectors = 1;
  s6a_air.visited_plmn.mcc_digit2 = 0,
    s6a_air.visited_plmn.mcc_digit1 = 8, s6a_air.visited_plmn.mcc_digit3 = 2, s6a_air.visited_plmn.mnc_digit1 = 0, s6a_air.visited_plmn.mnc_digit2 = 3, s6a_air.visited_plmn.mnc_digit3 = 4, s6a_generate_authentication_info_req (&s6a_air);
  // #else
  //     s6a_update_location_req_t s6a_ulr;
  //
  //     memset(&s6a_ulr, 0, sizeof(s6a_update_location_req_t));
  //
  //     sprintf(s6a_ulr.imsi, "%14llu", 20834123456789ULL);
  //     s6a_ulr.initial_attach = INITIAL_ATTACH;
  //     s6a_ulr.rat_type = RAT_EUTRAN;
  //     s6a_generate_update_location(&s6a_ulr);
#endif
}

int
s6a_fd_new_peer (
  void)
{
  char                                    host_name[100];
  size_t                                  host_name_len = 0;
  int                                     ret = 0;
#if FD_CONF_FILE_NO_CONNECT_PEERS_CONFIGURED
  struct peer_info                        info = {0};
#endif

  if (mme_config_read_lock (&mme_config) ) {
    OAILOG_ERROR (LOG_S6A, "Failed to lock configuration for reading\n");
    return RETURNerror;
  }

  if (fd_g_config->cnf_diamid ) {
    free (fd_g_config->cnf_diamid);
    fd_g_config->cnf_diamid_len = 0;
  }

  DevAssert (gethostname (host_name, 100) == 0);
  host_name_len = strlen (host_name);
  host_name[host_name_len] = '.';
  host_name[host_name_len + 1] = '\0';
  strcat (host_name, (const char *)mme_config.realm->data);
  fd_g_config->cnf_diamid = strdup (host_name);
  fd_g_config->cnf_diamid_len = strlen (fd_g_config->cnf_diamid);
  OAILOG_DEBUG (LOG_S6A, "Diameter identity of MME: %s with length: %zd\n", fd_g_config->cnf_diamid, fd_g_config->cnf_diamid_len);
  bstring                                 hss_name = bstrcpy(mme_config.s6a_config.hss_host_name);
  bconchar(hss_name, '.');
  bconcat (hss_name, mme_config.realm);

#if FD_CONF_FILE_NO_CONNECT_PEERS_CONFIGURED
  info.pi_diamid    = bdata(hss_name);
  info.pi_diamidlen = blength (hss_name);
  OAILOG_DEBUG (LOG_S6A, "Diameter identity of HSS: %s with length: %zd\n", info.pi_diamid, info.pi_diamidlen);
  info.config.pic_flags.sec     = PI_SEC_NONE;
  info.config.pic_flags.pro3    = PI_P3_DEFAULT;
  info.config.pic_flags.pro4    = PI_P4_TCP;
  info.config.pic_flags.alg     = PI_ALGPREF_TCP;
  info.config.pic_flags.exp     = PI_EXP_INACTIVE;
  info.config.pic_flags.persist = PI_PRST_NONE;
  info.config.pic_port          = 3868;
  info.config.pic_lft           = 3600;
  info.config.pic_tctimer       = 7; // retry time-out connection
  info.config.pic_twtimer       = 60; // watchdog
  CHECK_FCT (fd_peer_add (&info, "", s6a_peer_connected_cb, NULL));

  if (mme_config_unlock (&mme_config) ) {
    OAILOG_ERROR (LOG_S6A, "Failed to unlock configuration\n");
    return RETURNerror;
  }
  return ret;
#else
  DiamId_t          diamid    = bdata(hss_name);
  size_t            diamidlen = blength (hss_name);
  struct peer_hdr  *peer      = NULL;
  int               nb_tries  = 0;
  do {
    ret = fd_peer_getbyid( diamid, diamidlen, 0, &peer );
    if (!ret) {
      if (peer) {
        ret = fd_peer_get_state(peer);
        if (STATE_OPEN == ret) {
          MessageDef                             *message_p;

          OAILOG_DEBUG (LOG_S6A, "Peer %*s is now connected...\n", (int)diamidlen, diamid);
          /*
           * Inform S1AP that connection to HSS is established
           */
          message_p = itti_alloc_new_message (TASK_S6A, ACTIVATE_MESSAGE);
          itti_send_msg_to_task (TASK_S1AP, INSTANCE_DEFAULT, message_p);

          if (RUN_MODE_SCENARIO_PLAYER == mme_config.run_mode) {
            message_p = itti_alloc_new_message (TASK_S6A, ACTIVATE_MESSAGE);
            itti_send_msg_to_task (TASK_MME_SCENARIO_PLAYER, INSTANCE_DEFAULT, message_p);
          }
          {
            FILE *fp = NULL;
            bstring  filename = bformat("/tmp/mme_%d.status", g_pid);
            fp = fopen(bdata(filename), "w+");
            bdestroy_wrapper (&filename);
            fprintf(fp, "STARTED\n");
            fflush(fp);
            fclose(fp);
          }
          bdestroy_wrapper (&hss_name);
          return RETURNok;
        } else {
          OAILOG_DEBUG (LOG_S6A, "S6a peer state is %d\n", ret);
        }
      }
    } else {
      OAILOG_DEBUG (LOG_S6A, "Could not get S6a peer\n");
    }
    sleep(1);
  } while (nb_tries < 8);
  bdestroy_wrapper (&hss_name);
  return RETURNerror;
#endif
}
